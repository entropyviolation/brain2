.. include:: ../NEWS.rst
